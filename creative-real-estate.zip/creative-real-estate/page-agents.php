<?php
/**
 * Template Name: Agent page
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Real_Estate_theme
 */

get_header();
?>
<div class="about-page-container">
    <?php
    $about_background_image = get_field('agent_bg_image');
    $bg_image = $about_background_image ? esc_url($about_background_image['url']) : '';
    ?>
    <section id="hero-section" class="hero-section section m-lg-auto" style="
            background: linear-gradient(0deg, rgba(16,14,15,0.35), rgba(16,14,15,0.35)), url(<?php echo $bg_image; ?>);
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
            height: 450px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
        ">
        <h1 class="hero-heading text-white text-center mb-4" style="text-shadow: 0 20px 20px black;">
            <?php echo esc_html(get_field('agent_title')); ?>
        </h1>
        <h3 class="hero-heading text-white text-center mb-4" style="text-shadow: 0 20px 20px black;">
            <?php echo esc_html(get_field('agent_description')); ?>
        </h3>
    </section>

    <section class="team-section mt-3" id="team-section">
        <div class="container">
            <div class="row">
                <div class="team-section" style="padding:40px 0; text-align: center;">
                    <?php
                    $team_heading = get_field('agent_title');
                    if ($team_heading): ?>
                        <h1 style="font-size: 50px; font-weight: bold; margin-bottom: 10px;">
                            <?php echo esc_html($team_heading); ?>
                        </h1>
                        <div class="separator"
                        style="width: 100px; height: 4px; background-color: #10AC84; margin: 0 auto;">
                    </div>
                    <?php endif; ?>

                    <div class="team-cards mt-5" style="display: flex; justify-content: center; flex-wrap: wrap; gap: 45px;">
                        <?php
                        // Loop through 4 steps
                        for ($i = 1; $i <= 6; $i++):
                            // Get ACF field values
                            $team_image = get_field('agent_image_' . $i);
                            $team_member = get_field('agent_name_' . $i);
                            $team_member_designation = get_field('agent_designation_' . $i);
                            ?>
                            <div class="step-item" style="text-align: center; max-width: 250px;">
                                <div class="step-image" style="position: relative; margin-bottom: 40px;">
                                    <?php if ($team_image): ?>
                                        <img src="<?php echo esc_url($team_image['url']); ?>"
                                            alt="Team Member <?php echo $i; ?>"
                                            style="width: 250px; height: 300px; object-fit: cover; box-shadow: 0 10px 10px #a5a4a4; border-radius: 0px;background-position:center;"
                                            class="team-image">
                                    <?php endif; ?>
                                </div>
                                <h3 style="font-size: 25px; font-weight: bold; margin-bottom: 10px;">
                                    <?php echo esc_html($team_member); ?>
                                </h3>
                                <p style="font-size: 18px; color: #666;"><?php echo esc_html($team_member_designation); ?>
                                </p>
                            </div>
                        <?php endfor; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="agent-bg">
    <?php
    $about_contact_image = get_field('agent_contact_image');
    $about_bg_image = $about_contact_image ? esc_url($about_contact_image['url']) : '';
    ?>
        <div class="hero">
            <img alt="Beautiful view of a coastal town with white buildings and a blue sea" height="1080"
                src= <?php echo $about_bg_image; ?> />
            <div class="hero-content">
                <h1>
                <?php echo esc_html(get_field('agent_contact_heading')); ?>
                </h1>
                <p>
                <?php echo esc_html(get_field('agent_contact_description')); ?>
                </p>
                <a class="btn" href="#">
                    Explore Rentals
                </a>
            </div>
        </div>
    </section>

    <style>
        .hero {
            position: relative;
            width: 100%;
            height: 80vh;
            overflow: hidden;
        }

        .hero img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .hero::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            /* Adjust opacity here */
            z-index: 1;
        }

        .hero-content {
            position: absolute;
            top: 50%;
            left: 70%;
            width: 40%;
            transform: translate(-50%, -50%);
            text-align: left;
            color: white;
            z-index: 2;
            /* Ensure content is above the overlay */
        }

        .hero-content h1 {
            font-size: 2.2em;
            margin: 0;
        }

        .hero-content p {
            font-size: 1em;
            margin: 20px 0;
        }

        .hero-content .btn {
            background-color: #ff4b5c;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            font-size: 1em;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .hero-content .btn:hover {
            background-color: #e43a4f;
        }

        @media (max-width: 768px) {
            .hero-content h1 {
                font-size: 2em;
            }

            .hero-content p {
                font-size: 1em;
            }

            .hero-content .btn {
                padding: 10px 20px;
                font-size: 0.9em;
            }
        }
    </style>
    
    <?php
get_footer();