<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Real_Estate_theme
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
	<style>
		.nav-link{
			font-family: var(--font-family);
			font-style: normal;
			font-weight: 600;
			font-size: 18px;
			line-height: 30px;
			color: #333 !important;
		}
	</style>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'creative-real-estate' ); ?></a>

	<header id="masthead" class="site-header">
		<nav class="navbar navbar-expand-md navbar-light bg-light p-0" role="navigation" style="background-color: white !important;
    padding: 0;
    height: 70px;">
			<div class="container">
				<!-- Brand and toggle get grouped for better mobile display -->
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-controls="bs-example-navbar-collapse-1" aria-expanded="false" aria-label="<?php esc_attr_e( 'Toggle navigation', 'your-theme-slug' ); ?>">
					<span class="navbar-toggler-icon"></span>
				</button>
				<a href="#" class="navbar-brand">
					<div class="site-branding">
						<?php
						// Ensure the logo is displayed on the homepage
						if ( has_custom_logo() ) :
							the_custom_logo();  // Display the custom logo
						else :
							// Display site title if no custom logo is set
							if ( is_front_page() && is_home() ) :
								echo '<h1 class="site-title"><a href="' . esc_url( home_url( '/' ) ) . '" rel="home">' . get_bloginfo( 'name' ) . '</a></h1>';
							else :
								echo '<p class="site-title"><a href="' . esc_url( home_url( '/' ) ) . '" rel="home">' . get_bloginfo( 'name' ) . '</a></p>';
							endif;
						endif;
						?>
						<?php
						$creative_real_estate_description = get_bloginfo( 'description', 'display' );
						if ( $creative_real_estate_description || is_customize_preview() ) :
						?>
							<p class="site-description"><?php echo $creative_real_estate_description; ?></p>
						<?php endif; ?>
					</div><!-- .site-branding -->
				</a>

					<?php
						wp_nav_menu( array(
							'theme_location'    => 'primary',
							'depth'             => 3,
							'container'         => 'div',
							'container_class'   => 'collapse navbar-collapse',
							'container_id'      => 'bs-example-navbar-collapse-1',
							'menu_class'        => 'nav navbar-nav ml-auto',
							'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
							'walker'            => new WP_Bootstrap_Navwalker(),
						) );
					?>
					
			</div>
		</nav><!-- #site-navigation -->
	</header><!-- #masthead -->
