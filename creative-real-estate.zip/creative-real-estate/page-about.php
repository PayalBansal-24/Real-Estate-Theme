<?php
/**
 * Template Name: About page
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Real_Estate_theme
 */

get_header();
?>
<div class="about-page-container">
    <?php
    $hero_background_image = get_field('about_us_image');
    $bg_image = $hero_background_image ? esc_url($hero_background_image['url']) : '';
    ?>
    <section id="hero-section" class="hero-section section m-lg-auto" style="
            background: linear-gradient(0deg, rgba(16,14,15,0.35), rgba(16,14,15,0.35)), url(<?php echo $bg_image; ?>);
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
            height: 450px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
        ">
        <h1 class="hero-heading text-white text-center mb-4" style="text-shadow: 0 20px 20px black;">
            <?php echo esc_html(get_field('about_us_text')); ?>
        </h1>
        <h3 class="hero-heading text-white text-center mb-4" style="text-shadow: 0 20px 20px black;">
            <?php echo esc_html(get_field('about_us_description')); ?>
        </h3>
    </section>
    <section class="content-section">
        <?php
        $about_background_image = get_field('about_us_image_1');
        $about_image = $about_background_image ? esc_url($about_background_image['url']) : '';
        ?>
        <div class="container">
            <div class="row">
                <div class="col-md-6 image-container">
                    <img src="<?php echo $about_image; ?>" alt="Description" class="img-fluid" />
                </div>
                <div class="col-md-6 text-container">
                    <h2><?php echo esc_html(get_field('about_us_text_1')); ?></h2>
                    <p>
                        <?php echo esc_html(get_field('about_us_description_1')); ?>
                    </p>
                </div>
            </div>
        </div>
        <style>
            .content-section {
                padding: 60px 0;
            }

            .image-container img {
                width: 100%;
                height: 600px;
                border-radius: 8px;
                z-index: 1;
                box-shadow: -20px 0px 40px rgb(206, 206, 206);
                /* Optional for rounded corners */
            }

            .text-container {
                display: flex;
                flex-direction: column;
                justify-content: center;
                padding-left: 20px;
                padding: 30px;
                background-color: white;
                margin-left: -120px;
                z-index: 9;
                height: 450px;
                margin-top: 80px;

            }

            .text-container h2 {
                font-size: 32px;
                font-weight: 700;
                margin-bottom: 20px;
            }

            .text-container p {
                font-size: 16px;
                color: #555;
                line-height: 1.8;
                margin-bottom: 15px;
            }
        </style>
    </section>

    <section class="about-city-container">
        <div class="city-container">
            <div class="city">
                <img alt="San Francisco cityscape with a bridge at sunset" height="400"
                    src="https://storage.googleapis.com/a1aa/image/37HzeefrIBUXIo5tVekfctTOaak30cRVxneK3dYhByu9xoVAF.jpg"
                    width="600" />
                <div class="overlay">
                    <h2>
                        San Francisco
                    </h2>
                    <div class="properties">
                        <h3>
                            5
                        </h3>
                        <p>
                            Properties
                        </p>
                    </div>
                </div>
            </div>
            <div class="city">
                <img alt="Miami cityscape with water and boats" height="400"
                    src="https://storage.googleapis.com/a1aa/image/1nyonNgoYRa7LFWECWvLUpfOQXlUzhD3IJxTuSF1yEFmRrAKA.jpg"
                    width="600" />
                <div class="overlay">
                    <h2>
                        Miami
                    </h2>
                    <div class="properties">
                        <h3>
                            6
                        </h3>
                        <p>
                            Properties
                        </p>
                    </div>
                </div>
            </div>
            <div class="city">
                <img alt="Orlando cityscape with water and buildings" height="400"
                    src="https://storage.googleapis.com/a1aa/image/9sXZw1toT4KfKSM3LAUhquqD8yChIvDrlAHokwNBKvwkRrAKA.jpg"
                    width="600" />
                <div class="overlay">
                    <h2>
                        Orlando
                    </h2>
                    <div class="properties">
                        <h3>
                            6
                        </h3>
                        <p>
                            Properties
                        </p>
                    </div>
                </div>
            </div>
            <div class="city">
                <img alt="New York cityscape with a park and buildings" height="400"
                    src="https://storage.googleapis.com/a1aa/image/itzMxg2iXtL4G9xvuKrxkAwt3eQJXbcUk16KlOqXSxOoRrAKA.jpg"
                    width="600" />
                <div class="overlay">
                    <h2>
                        New York
                    </h2>
                    <div class="properties">
                        <h3>
                            6
                        </h3>
                        <p>
                            Properties
                        </p>
                    </div>
                </div>
            </div>
            <div class="city">
                <img alt="Los Angeles cityscape with water and buildings" height="400"
                    src="https://storage.googleapis.com/a1aa/image/n0eLFHkfmCgbtEvucUfn6TMZXetOX2vxOIqjUesfDVfSlRrAKA.jpg"
                    width="600" />
                <div class="overlay">
                    <h2>
                        Los Angeles
                    </h2>
                    <div class="properties">
                        <h3>
                            4
                        </h3>
                        <p>
                            Properties
                        </p>
                    </div>
                </div>
            </div>
            <div class="city">
                <img alt="Chicago cityscape with a fountain and buildings" height="400"
                    src="https://storage.googleapis.com/a1aa/image/gmP79Mc0vq6XORExTmPn8fd1fAeRLxUhF18Hc3stHKZdGtCoA.jpg"
                    width="600" />
                <div class="overlay">
                    <h2>
                        Chicago
                    </h2>
                    <div class="properties">
                        <h3>
                            4
                        </h3>
                        <p>
                            Properties
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="category-property-section p-5" id="category-property-section" style="background:#F5F6F7;">
        <div class="container">
            <div class="row">
                <div class="steps-section"
                    style="display: flex; justify-content: space-between; align-items: flex-start; gap: 45px;padding:40px 0">
                    <?php
                    // Loop through 4 steps
                    for ($i = 1; $i <= 4; $i++):
                        // Get ACF field values
                        $step_number = get_field('steps_number_' . $i);
                        $step_image = get_field('steps_image_' . $i);
                        $category_title = get_field('category_title_' . $i);
                        $category_description = get_field('category_description_' . $i);
                        ?>
                        <div class="step-item" style="text-align: center; max-width: 250px;">
                            <div class="step-image" style="position: relative; margin-bottom: 40px;">
                                <?php if ($step_image): ?>
                                    <img src="<?php echo esc_url($step_image['url']); ?>" alt="Step <?php echo $i; ?>"
                                        style="width: 220px; height: 220px; border-radius: 50%; object-fit: cover;box-shadow:0 10px 10px #a5a4a4;border:2px solid #0f9d58"
                                        class="steps-image">
                                <?php endif; ?>
                                <div class="step-number"
                                    style="position: absolute; bottom: -20px; left: 50%; transform: translateX(-50%); background-color: #0f9d58; color: white; width: 50px; height: 50px; border-radius: 50%; display: flex; justify-content: center; align-items: center; font-weight: bold;">
                                    <?php echo esc_html($step_number); ?>
                                </div>
                            </div>
                            <h3 style="font-size: 25px; font-weight: bold; margin-bottom: 10px;">
                                <?php echo esc_html($category_title); ?></h3>
                            <p style="font-size: 18px; color: #666;"><?php echo esc_html($category_description); ?></p>
                        </div>
                    <?php endfor; ?>
                </div>
            </div>
        </div>
    </section>

    <section class="testimonials-section">
        <div class="container">
            <h2 style="margin-bottom:20px;">What People Say About Us</h2>
            <div class="separator"
                        style="width: 100px; height: 4px; background-color: #10AC84; margin: 0 auto;"></div>
            <div class="row mt-3">
                <!-- Testimonial 1 -->
                <div class="col-md-4">
                    <div class="testimonial-item">
                        <p class="testimonial-content">
                            <?php echo esc_html(get_field('testinomial_description_1')); ?>
                        </p>
                        <p class="testimonial-author">
                            — <?php echo esc_html(get_field('testinomial_client_name_1')); ?>
                        </p>
                        <div class="star-rating">
                        <span class="star">&#9733;</span>
                        <span class="star">&#9733;</span>
                        <span class="star">&#9733;</span>
                        <span class="star">&#9733;</span>
                        <span class="star">&#9733;</span>
                    </div>
                    </div>
                </div>

                <!-- Testimonial 2 -->
                <div class="col-md-4">
                    <div class="testimonial-item">
                        <p class="testimonial-content">
                            <?php echo esc_html(get_field('testinomial_description_2')); ?>
                        </p>
                        <p class="testimonial-author">
                            — <?php echo esc_html(get_field('testinomial_client_name_2')); ?>
                        </p>
                        <div class="star-rating">
                        <span class="star">&#9733;</span>
                        <span class="star">&#9733;</span>
                        <span class="star">&#9733;</span>
                        <span class="star">&#9733;</span>
                        <span class="star">&#9733;</span>
                    </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="testimonial-item">
                        <p class="testimonial-content">
                            <?php echo esc_html(get_field('testinomial_description_3')); ?>
                        </p>
                        <p class="testimonial-author">
                            — <?php echo esc_html(get_field('testinomial_client_name_3')); ?>
                        </p>
                        <div class="star-rating">
                        <span class="star">&#9733;</span>
                        <span class="star">&#9733;</span>
                        <span class="star">&#9733;</span>
                        <span class="star">&#9733;</span>
                        <span class="star">&#9733;</span>
                    </div>
                    </div>
                </div>

                <!-- Add more testimonials similarly -->
            </div>
        </div>
        <style>
            .testimonials-section {
                padding: 60px 0;
                background-color:white;
                text-align: center;
            }

            .testimonials-section h2 {
                font-size: 38px;
                font-weight: bold;
                margin-bottom: 30px;
                color: #333;
            }

            .testimonial-item {
                background-color: #fff;
                padding: 20px;
                border-radius: 10px;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                margin-bottom: 20px;
            }

            .testimonial-content {
                font-size: 16px;
                color: #666;
                margin-bottom: 10px;
                font-style: italic;
            }

            .testimonial-author {
                font-size: 18px;
                font-weight: bold;
                color: #333;
            }


            .city-container {
                display: flex;
                flex-wrap: wrap;
            }

            .city {
                position: relative;
                width: 33.33%;
                height: 50vh;
                overflow: hidden;
            }

            .city img {
                width: 100%;
                height: 100%;
                object-fit: cover;
                transition: transform 0.3s ease;
                /* Smooth zoom effect */
                transform-origin: center;
                /* Keeps the zoom centered */
            }

            .city:hover img {
                transform: scale(1.1);
                /* Zoom in effect */
            }

            .city .overlay {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.3);
                color: white;
                display: flex;
                flex-direction: column;
                justify-content: space-between;
                padding: 20px;
                transition: visibility 0.3s ease, opacity 0.3s ease;
                /* Smoothly fade out */
            }

            .city:hover .overlay {
                visibility: hidden;
                /* Hide the overlay on hover */
                opacity: 0;
                /* Fade out the overlay */
            }

            .city .overlay h2 {
                margin: 0;
            }

            .city .overlay .properties {
                text-align: right;
            }

            @media (max-width: 768px) {
                .city {
                    width: 50%;
                    height: 30vh;
                }
            }

            @media (max-width: 480px) {
                .city {
                    width: 100%;
                    height: 30vh;
                }
            }
        </style>
    </section>

</div>
<?php
get_footer();
