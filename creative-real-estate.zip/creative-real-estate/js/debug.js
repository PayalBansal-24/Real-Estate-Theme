document.addEventListener('DOMContentLoaded', function () {
    if (typeof propertyData !== 'undefined') {
        console.log('Background Image:', propertyData.bgImage);
        console.log('Page Heading:', propertyData.heading);
    } else {
        console.log('No property data found.');
    }
});
