<?php
/**
 * Template Name: Property page
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Real_Estate_theme
 */

get_header();
?>
<div class="home-page-container">
    <?php
    $hero_background_image = get_field('property_page_bg_image');
    $bg_image = $hero_background_image ? esc_url($hero_background_image['url']) : '';
    ?>
    <section id="hero-section" class="hero-section section m-lg-auto" style="
            background: linear-gradient(0deg, rgba(16,14,15,0.35), rgba(16,14,15,0.35)), url(<?php echo $bg_image; ?>);
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
            height: 450px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
        ">
        <h1 class="hero-heading text-white text-center mb-4" style="text-shadow: 0 20px 20px black;">
            <?php echo esc_html(get_field('property_page_heading')); ?>
        </h1>
        <h3 class="hero-heading text-white text-center mb-4" style="text-shadow: 0 20px 20px black;">
            <?php echo esc_html(get_field('property_page_sub_heading')); ?>
        </h3>
    </section>

    <section class="featured-property-section mt-5" id="featured-property-section" style="background: white;">
        <div class="container">
            <div class="row text-center">
                <div class="col-lg-8 mx-auto col-sm-12 col-xs-12">
                    <h2 class="section-heading item-space" style="font-weight: 700; font-size: 42px; color: black;">
                        Searching for Best Place?</h2>
                    <div class="separator"
                        style="width: 100px; height: 4px; background-color: #10AC84; margin: 0 auto;"></div>
                    <p class="section-description mt-2 item-space" style="font-size: 18px; color: black;">Discover the
                        perfect destination that combines luxury, comfort, and convenience.</p>
                </div>
            </div>
            <div class="row item-space">
                <div class="col-lg-12">
                    <form action="<?php echo esc_url(get_permalink()); ?>" method="get" style="margin-top: 10px;">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="property_type">Looking For</label>
                                    <select name="property_type" id="property_type" class="form-control">
                                        <option value="">Select Property</option> <!-- Default option -->
                                        <?php
                                        $property_types = get_terms(array(
                                            'taxonomy' => 'property_type',
                                            'hide_empty' => false,
                                        ));
                                        foreach ($property_types as $property_type) {
                                            echo '<option value="' . esc_attr($property_type->slug) . '">' . esc_html($property_type->name) . '</option>';
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="property_size">Property Size</label>
                                    <select name="property_size" id="property_size" class="form-control">
                                        <option value="">Select Property Size</option> <!-- Default option -->
                                        <?php
                                        $args = array(
                                            'post_type' => 'property',
                                            'post_status' => 'publish',
                                        );
                                        $the_query = new WP_Query($args);
                                        if ($the_query->have_posts()) {
                                            while ($the_query->have_posts()) {
                                                $the_query->the_post();
                                                $property_size = get_field('property_size', get_the_ID());
                                                echo '<option value="' . esc_attr($property_size) . '">' . esc_html($property_size) . ' sq. ft.</option>';
                                            }
                                        }
                                        wp_reset_postdata();
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="property_location">Location</label>
                                    <select name="property_location" id="property_location" class="form-control">
                                        <option value="">Select Location</option> <!-- Default option -->
                                        <?php
                                        $locations = get_terms(array(
                                            'taxonomy' => 'location',
                                            'hide_empty' => false,
                                        ));
                                        foreach ($locations as $location) {
                                            echo '<option value="' . esc_attr($location->slug) . '">' . esc_html($location->name) . '</option>';
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="price">Property Price</label>
                                    <select name="price" id="price" class="form-control">
                                        <option value="">Select Price</option> <!-- Default option -->
                                        <?php
                                        $args = array(
                                            'post_type' => 'property',
                                            'post_status' => 'publish',
                                            'posts_per_page' => -1, // Fetch all properties
                                        );
                                        $the_query = new WP_Query($args);

                                        if ($the_query->have_posts()) {
                                            while ($the_query->have_posts()) {
                                                $the_query->the_post();
                                                $price = get_field('price', get_the_ID()); // Fetch the price field
                                                if ($price) { // Only display options for valid prices
                                                    echo '<option value="' . esc_attr($price) . '">' . 'Rs. ' . esc_html(number_format($price)) . '</option>';
                                                }
                                            }
                                        } else {
                                            echo '<option value="">No Properties Available</option>'; // Fallback if no properties found
                                        }
                                        wp_reset_postdata();
                                        ?>
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="bed">Totel Beds</label>
                                    <select name="bed" id="bed" class="form-control">
                                        <option value="">Beds</option> <!-- Default option -->
                                        <?php
                                        $args = array(
                                            'post_type' => 'property',
                                            'post_status' => 'publish',
                                        );
                                        $the_query = new WP_Query($args);
                                        if ($the_query->have_posts()) {
                                            while ($the_query->have_posts()) {
                                                $the_query->the_post();
                                                $bed = get_field('bed', get_the_ID());
                                                echo '<option value="' . esc_attr($bed) . '">' . esc_html($bed) . ' Bed </option>';
                                            }
                                        }
                                        wp_reset_postdata();
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="bath">Total Bath</label>
                                    <select name="bath" id="bath" class="form-control">
                                        <option value="">Bath</option> <!-- Default option -->
                                        <?php
                                        $args = array(
                                            'post_type' => 'property',
                                            'post_status' => 'publish',
                                        );
                                        $the_query = new WP_Query($args);
                                        if ($the_query->have_posts()) {
                                            while ($the_query->have_posts()) {
                                                $the_query->the_post();
                                                $bath = get_field('bath', get_the_ID());
                                                echo '<option value="' . esc_attr($bath) . '">' . esc_html($bath) . ' Bath</option>';
                                            }
                                        }
                                        wp_reset_postdata();
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="submit" style="visibility: hidden;">Submit</label>
                                    <input type="submit" class="btn btn-success form-control" value="Search"
                                        style="background-color: #10AC84; color: white; padding: 10px;">
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <div class="row item-space mt-5">
                <?php
                // WP Query for properties with search filters
                $args = array(
                    'post_type' => 'property',
                    'posts_per_page' => 6,
                    'paged' => get_query_var('paged') ? get_query_var('paged') : 1,
                    'post_status' => 'publish',
                );

                // Add search filters
                if (!empty($_GET['property_type'])) {
                    $args['tax_query'][] = array(
                        'taxonomy' => 'property_type',
                        'field' => 'slug',
                        'terms' => sanitize_text_field($_GET['property_type']),
                    );
                }

                if (!empty($_GET['property_location'])) {
                    $args['tax_query'][] = array(
                        'taxonomy' => 'location',
                        'field' => 'slug',
                        'terms' => sanitize_text_field($_GET['property_location']),
                    );
                }

                if (!empty($_GET['property_size'])) {
                    $args['meta_query'][] = array(
                        'key' => 'property_size',
                        'value' => sanitize_text_field($_GET['property_size']),
                        'compare' => '=',
                    );
                }

                if (!empty($_GET['price'])) {
                    $args['meta_query'][] = array(
                        'key' => 'price',
                        'value' => sanitize_text_field($_GET['price']),
                        'compare' => '=',
                    );
                }

                if (!empty($_GET['bed'])) {
                    $args['meta_query'][] = array(
                        'key' => 'bed',
                        'value' => sanitize_text_field($_GET['bed']),
                        'compare' => '=',
                    );
                }

                if (!empty($_GET['bath'])) {
                    $args['meta_query'][] = array(
                        'key' => 'bath',
                        'value' => sanitize_text_field($_GET['bath']),
                        'compare' => '=',
                    );
                }

                $query = new WP_Query($args);

                if ($query->have_posts()):
                    while ($query->have_posts()):
                        $query->the_post();
                        $price = get_field('price');
                        $bedrooms = get_field('bed');
                        $bathrooms = get_field('bath');
                        $rooms = get_field('rooms');
                        $size = get_field('property_size');
                        $location_terms = wp_get_post_terms(get_the_ID(), 'location');
                        $location_name = !empty($location_terms) ? $location_terms[0]->name : 'N/A';
                        ?>
                        <div class="col-lg-4 col-md-6 col-sm-12 col-xm-12 item-space mb-4">
                            <div class="property-card" style="border: 1px solid #e3e3e3; border-radius: 8px; overflow: hidden;">
                                <?php if (has_post_thumbnail()): ?>
                                    <div class="property-image" style="height: 250px; overflow: hidden;">
                                        <img src="<?php the_post_thumbnail_url('medium'); ?>" alt="<?php the_title(); ?>"
                                            style="width: 100%; height: 100%; object-fit: cover;">
                                    </div>
                                <?php endif; ?>
                                <div class="property-details" style="padding: 15px;">
                                    <h3 class="property-title" style="font-size: 22px; font-weight: bold; color: #333;">
                                        <?php the_title(); ?>
                                    </h3>
                                    <p class="property-location" style="color: #888; margin-bottom: 10px;font-size:16px;">
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/location.png"
                                            alt="Location" style="width:20px;" /> <?php echo esc_html($location_name); ?>
                                    </p>
                                    <p class="property-info" style="color: #555;font-size:12px;">
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/bed.png" alt="Bed"
                                            style="width:20px;" />&nbsp; <?php echo esc_html($bedrooms); ?> Bed
                                        &nbsp;&nbsp;&nbsp;<img src="<?php echo get_template_directory_uri(); ?>/assets/bath.png"
                                            alt="Bath" style="width:20px;" /> &nbsp;<?php echo esc_html($bathrooms); ?> Bath
                                        &nbsp;&nbsp;&nbsp;<img
                                            src="<?php echo get_template_directory_uri(); ?>/assets/rooms.png" alt="Rooms"
                                            style="width:20px;" /> &nbsp;<?php echo esc_html($bathrooms); ?> Rooms
                                        &nbsp;&nbsp;&nbsp;<img src="<?php echo get_template_directory_uri(); ?>/assets/size.png"
                                            alt="size" style="width:20px;" /> &nbsp;<?php echo esc_html($size); ?> sq. ft.
                                    </p>
                                    <p class="property-price" style="color: #10AC84; font-weight: bold; font-size: 18px;">
                                        Rs. <?php echo number_format($price); ?>/-
                                    </p>
                                    <button class="btn"
                                        style="background-color: #10AC84;padding:5px 10px;color:white;font-size:15px;">See
                                        More</button>
                                </div>
                            </div>
                        </div>
                    <?php endwhile;

                    // Pagination
                    echo '<div class="pagination-wrapper mx-auto">';
                    echo paginate_links(array(
                        'total' => $query->max_num_pages,
                        'current' => max(1, get_query_var('paged')),
                        'prev_text' => __('&laquo; Previous'),
                        'next_text' => __('Next &raquo;'),
                    ));
                    echo '</div>';

                    wp_reset_postdata();
                else:
                    echo '<p>No properties found based on your search criteria.</p>';
                endif;
                ?>

            </div>
            <style>
                .pagination-wrapper {
                    text-align: center;
                    /* Center-align the pagination */
                    margin-top: 30px;
                    /* Add some spacing above */
                }

                .pagination-wrapper .page-numbers {
                    display: inline-block;
                    margin: 0 5px;
                    /* Space between links */
                    padding: 10px 15px;
                    background-color: #10AC84;
                    /* Background color */
                    color: #fff;
                    /* Text color */
                    font-size: 16px;
                    font-weight: bold;
                    text-decoration: none;
                    border-radius: 5px;
                    /* Rounded corners */
                    transition: background-color 0.3s ease-in-out;
                }

                .pagination-wrapper .page-numbers:hover {
                    background-color: #0f8d6a;
                    /* Darker shade on hover */
                    color: #fff;
                    /* Ensure text stays white */
                }

                .pagination-wrapper .page-numbers.current {
                    background-color: #0c6a52;
                    /* Current page background */
                    color: #fff;
                    /* Current page text color */
                    pointer-events: none;
                    /* Disable clicks on the current page */
                }
            </style>
        </div>
    </section>

    <section class="property-section mt-3" id="property-section">
        <div class="container-fluid">
            <div class="row">
                <div class="property-section" style="padding:40px 0; text-align: center;">
                    <div class="property-cards" style="display: flex; justify-content: center; flex-wrap: wrap;">
                        <?php
                        // Loop through 5 properties
                        for ($i = 1; $i <= 5; $i++):
                            // Get ACF field values
                            $property_image = get_field('property_city_images_' . $i);
                            $city_title = get_field('property_city_' . $i);
                            $city_url = get_field('property_city_url_' . $i);
                            ?>
                            <div class="property-item"
                                style="text-align: center; max-width: 400px; position: relative; margin-bottom: 40px;">
                                <div class="property-image"
                                    style="position: relative; overflow: hidden; height: 400px;width:300px;">
                                    <?php if ($property_image): ?>
                                        <img src="<?php echo esc_url($property_image['url']); ?>"
                                            alt="Property <?php echo $i; ?>" class="property-image-img">
                                    <?php endif; ?>
                                </div>
                                <div class="browse-property"
                                    style="margin-top: 20px; position:relative; z-index:2; top:-110px;">
                                    <a href="<?php echo esc_url($city_url); ?>" class="btn"
                                        style="background-color: #140C40; color: white; font-size: 18px; padding: 10px 30px; border-radius:50px;"><?php echo esc_html($city_title); ?></a>
                                </div>
                            </div>
                        <?php endfor; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<style>
    .property-section {
        height: 400px;
    }
</style>

<?php
get_footer();
