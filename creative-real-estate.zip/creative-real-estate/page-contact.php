<?php
/**
 * Template Name: Contact page
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Real_Estate_theme
 */

get_header();
?>
<div class="contact-page-container">
    <?php
    $contact_background_image = get_field('contact_bg_image');
    $contact_image = $contact_background_image ? esc_url($contact_background_image['url']) : '';
    ?>
    <section id="contact-hero-section" class="contact-hero-section section m-lg-auto" style="
            background: linear-gradient(0deg, rgba(16,14,15,0.35), rgba(16,14,15,0.35)), url(<?php echo $contact_image; ?>);
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
            height: 450px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
        ">
        <h1 class="contact-hero-heading text-white text-center mb-4" style="text-shadow: 0 20px 20px black;">
            <?php echo esc_html(get_field('contact_heading')); ?>
        </h1>
        <h3 class="contact-hero-heading text-white text-center mb-4" style="text-shadow: 0 20px 20px black;">
            <?php echo esc_html(get_field('contact_sub_heading')); ?>
        </h3>
    </section>

    <section class="contact-info mt-5">
        <div class="container">
            <h1 class="text-center"><?php echo esc_html(get_field('contact_heading')); ?></h1>
            <div class="separator" style="width: 100px; height: 4px; background-color: #10AC84; margin: 0 auto;"></div>
            <div class="row mt-3"></div>
            <div class="contact-container">
                <div class="contact-info mt-5">
                    <div class="contact-item">
                        <i class="fas fa-phone-alt"></i>
                        <div>
                            <span><?php echo esc_html(get_field('label_phone')); ?></span>
                            <a href="tel:+123456789">+<?php echo esc_html(get_field('phone_number')); ?></a>
                        </div>
                    </div>
                    <div class="contact-item">
                        <i class="fas fa-mobile-alt"></i>
                        <div>
                            <span><?php echo esc_html(get_field('label_mobile')); ?></span>
                            <a href="tel:+133456787">+<?php echo esc_html(get_field('mobile_no')); ?></a>
                        </div>
                    </div>
                    <div class="contact-item">
                        <i class="fas fa-envelope"></i>
                        <div>
                            <span><?php echo esc_html(get_field('email_label')); ?></span>
                            <a href="mailto:sales@yourwebsite.com"><?php echo esc_html(get_field('email')); ?></a>
                        </div>
                    </div>
                    <div class="contact-item">
                        <i class="fas fa-map-marker-alt"></i>
                        <div>
                            <span><?php echo esc_html(get_field('address_label')); ?></span>
                            <a><?php echo esc_html(get_field('address')); ?></a>
                        </div>
                    </div>
                </div>
                <div class="map">
                    <iframe
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3151.835434509374!2d144.9537353153167!3d-37.81627977975159!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad642af0f11fd81%3A0xf577d1b6d4f0a1e!2s3015%20Grand%20Ave%2C%20Coconut%20Grove%2C%20Merrick%20Way%2C%20FL%2012345!5e0!3m2!1sen!2sus!4v1633021234567!5m2!1sen!2sus"
                        allowfullscreen="" loading="lazy"></iframe>
                </div>
            </div>
        </div>
    </section>

    <section class="agent-bg">
    <?php
    $about_contact_image = get_field('contact_image');
    $about_bg_image = $about_contact_image ? esc_url($about_contact_image['url']) : '';
    ?>
        <div class="hero">
            <img alt="Beautiful view of a coastal town with white buildings and a blue sea" height="1080"
                src= <?php echo $about_bg_image; ?> />
            <div class="hero-content">
                <h1>
                <?php echo esc_html(get_field('contact_heading_1')); ?>
                </h1>
                <p>
                <?php echo esc_html(get_field('contact_description')); ?>
                </p>
                <a class="btn" href="#">
                    Explore Rentals
                </a>
            </div>
        </div>
    </section>

    <style>
        .hero {
            position: relative;
            width: 100%;
            height: 80vh;
            overflow: hidden;
        }

        .hero img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .hero::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            /* Adjust opacity here */
            z-index: 1;
        }

        .hero-content {
            position: absolute;
            top: 50%;
            left: 70%;
            width: 40%;
            transform: translate(-50%, -50%);
            text-align: left;
            color: white;
            z-index: 2;
            /* Ensure content is above the overlay */
        }

        .hero-content h1 {
            font-size: 2.2em;
            margin: 0;
        }

        .hero-content p {
            font-size: 1em;
            margin: 20px 0;
        }

        .hero-content .btn {
            background-color: #ff4b5c;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            font-size: 1em;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .hero-content .btn:hover {
            background-color: #e43a4f;
        }

        @media (max-width: 768px) {
            .hero-content h1 {
                font-size: 2em;
            }

            .hero-content p {
                font-size: 1em;
            }

            .hero-content .btn {
                padding: 10px 20px;
                font-size: 0.9em;
            }
        }
        .contact-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }
        .contact-info, .map {
            flex: 1;
            min-width: 300px;
            margin: 10px;
        }
        .contact-item {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }
        .contact-item i {
            font-size: 24px;
            margin-right: 15px;
            color: #4a4a4a;
        }
        .contact-item div {
            display: flex;
            flex-direction: column;
        }
        .contact-item div span {
            font-size: 20px;
            font-weight: bold;
        }
        .contact-item div a {
            font-size: 18px;
            color: #4a4a4a;
            text-decoration: none;
        }
        .map iframe {
            width: 100%;
            height: 400px;
            border: 0;
        }
    </style>
</div>
<?php
get_footer();
