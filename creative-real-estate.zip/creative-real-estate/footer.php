<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Real_Estate_theme
 */
?>

<footer id="colophon" class="site-footer">
	<div class="footer-container">
		<div class="footer-row">
			<!-- Column 1: About -->
			<div class="footer-column">
				<a href="<?php echo home_url(); ?>">
					<?php
					if (has_custom_logo()) {
						the_custom_logo();
					} else {
						echo '<img src="' . esc_url(get_template_directory_uri() . '/assets/images/default-logo.png') . '" alt="Site Logo" class="footer-logo">';
					}
					?>

				</a>
				<p>
					We are a leading real estate platform dedicated to helping you find your dream property.
					Whether you're buying, selling, or renting, we're here to guide you every step of the way.
				</p>
			</div>

			<!-- Column 2: Quick Links -->
			<div class="footer-column">
				<h3>Quick Links</h3>
				<ul>
					<li><a href="<?php echo home_url(); ?>">Home</a></li>
					<li><a href="<?php echo home_url('/about'); ?>">About Us</a></li>
					<li><a href="<?php echo home_url('/property-page'); ?>">Properties</a></li>
					<li><a href="<?php echo home_url('/contact'); ?>">Contact Us</a></li>
				</ul>
			</div>

			<!-- Column 3: Contact Info -->
			<div class="footer-column">
				<h3>Contact Us</h3>
				<p>
					<strong>Email:</strong> info@realestate.com <br>
					<strong>Phone:</strong> +1 (234) 567-890 <br>
					<strong>Address:</strong> 123 Real Estate Lane, Cityville, USA
				</p>
			</div>

			<!-- Column 4: Social Media -->
			<div class="footer-column">
				<h3>Follow Us</h3>
				<div class="social-links">
					<a href="https://facebook.com" target="_blank" class="social-icon"><i
							class="fab fa-facebook-f"></i></a>
					<a href="https://twitter.com" target="_blank" class="social-icon"><i class="fab fa-twitter"></i></a>
					<a href="https://instagram.com" target="_blank" class="social-icon"><i
							class="fab fa-instagram"></i></a>
					<a href="https://linkedin.com" target="_blank" class="social-icon"><i
							class="fab fa-linkedin-in"></i></a>
				</div>
			</div>
		</div>

		<div class="footer-bottom">
			<p>
				&copy; <?php echo date('Y'); ?> Real Estate. All Rights Reserved. |
				<a href="<?php echo esc_url(home_url('/privacy-policy')); ?>">Privacy Policy</a>
			</p>
		</div>
	</div>
</footer>

<style>
	.footer-logo {
		max-width: 150px;
		margin-bottom: 20px;
		display: block;
	}

	.site-footer {
		background-color: #222;
		color: #fff;
		padding: 40px 20px;
	}

	.footer-container {
		max-width: 1600px;
		margin: 0 auto;
		text-align: left;
	}

	.footer-row {
		display: flex;
		flex-wrap: wrap;
		justify-content: space-between;
		margin-bottom: 20px;
	}

	.footer-column {
		flex: 1;
		min-width: 220px;
		margin: 10px 55px;
	}

	.footer-column h3 {
		font-size: 18px;
		margin-bottom: 10px;
		color: #fff;
		text-align: left;
	}

	.footer-column p,
	.footer-column ul,
	.footer-column li {
		font-size: 14px;
		line-height: 1.8;
		margin: 0;
		padding: 0;
		text-align: left;
	}

	.footer-column ul {
		list-style: none;
		padding: 0;
	}

	.footer-column ul li {
		margin-bottom: 8px;
	}

	.footer-column ul li a {
		color: #ddd;
		text-decoration: none;
	}

	.footer-column ul li a:hover {
		color: #006E78;
	}

	.social-links {
		display: flex;
		justify-content: flex-start;
		margin-top: 20px;
	}

	.social-icon {
		display: inline-flex;
		align-items: center;
		justify-content: center;
		width: 40px;
		height: 40px;
		background-color: #333;
		border-radius: 50%;
		margin-right: 10px;
		color: #fff;
		font-size: 18px;
		transition: all 0.3s ease;
	}

	.social-icon:hover {
		background-color: #006E78;
		color: #fff;
	}

	.footer-bottom {
		border-top: 1px solid #444;
		padding-top: 10px;
		font-size: 14px;
		color: #ccc;
		text-align: center;
	}

	.footer-bottom a {
		color: #ddd;
		text-decoration: none;
	}

	.footer-bottom a:hover {
		color: #006E78;
	}

	/* Responsive Design */
	@media (max-width: 768px) {
		.footer-row {
			flex-direction: column;
			align-items: flex-start;
		}

		.footer-column {
			margin: 10px 0;
			text-align: left;
		}

		.social-links {
			justify-content: flex-start;
		}
	}
</style>

<?php wp_footer(); ?>

</body>

</html>