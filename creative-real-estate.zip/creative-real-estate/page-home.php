<?php
/**
 * Template Name: Home page
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Real_Estate_theme
 */

get_header();
?>
<div class="home-page-container">
    <?php
    $hero_background_image = get_field('hero_background_image');
    $bg_image = $hero_background_image ? esc_url($hero_background_image['url']) : '';
    ?>
    <section id="hero-section" class="hero-section section m-lg-auto" style="background: linear-gradient(0deg, rgba(16,14,15,0.35), rgba(16,14,15,0.35)), url(<?php echo $bg_image; ?>); background-size: cover; background-repeat: no-repeat; background-position: center center; height: 750px; display: flex; align-items: center; justify-content: center; flex-direction: column;">
        <h1 class="hero-heading text-white text-center mb-4" style="text-shadow: 0 20px 20px black;">Find Your Dream Properties</h1>
        <div class="search-form bg-white" style="width: 920px; padding: 15px 30px; border-radius: 10px; box-shadow: 0 20px 20px black;">
            <h3>Search Your Properties</h3>
            <div class="separator" style="width: 43px; height: 4px; background-color: #10AC84; margin: 0;"></div>
            <form action="<?php echo home_url(); ?>/property" method="get" style="margin-top: 10px;">
                <div class="row">
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="property_type">Looking For</label>
                            <select name="property_type" id="property_type" class="form-control">
                                <?php
                                $property_types = get_terms(array(
                                    'taxonomy' => 'property_type',
                                    'hide_empty' => false,
                                ));
                                foreach ($property_types as $property_type) {
                                    echo '<option value="' . esc_attr($property_type->slug) . '">' . esc_html($property_type->name) . '</option>';
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="property_size">Property Size</label>
                            <select name="property_size" id="property_size" class="form-control">
                                <?php
                                $args = array(
                                    'post_type' => 'property',
                                    'post_status' => 'publish',
                                );
                                $the_query = new WP_Query($args);
                                if ($the_query->have_posts()) {
                                    while ($the_query->have_posts()) {
                                        $the_query->the_post();
                                        $property_size = get_field('property_size', get_the_ID());
                                        echo '<option value="' . esc_attr($property_size) . '">' . esc_html($property_size) . ' sq. ft.</option>';
                                    }
                                }
                                wp_reset_postdata();
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="property_location">Location</label>
                            <select name="property_location" id="property_location" class="form-control">
                                <?php
                                $locations = get_terms(array(
                                    'taxonomy' => 'location',
                                    'hide_empty' => false,
                                ));
                                foreach ($locations as $location) {
                                    echo '<option value="' . esc_attr($location->slug) . '">' . esc_html($location->name) . '</option>';
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="submit" style="visibility: hidden;">Submit</label>
                            <input type="submit" class="btn btn-success form-control" value="Search" style="background-color: #10AC84; color: white; padding: 10px;">
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </section>

    <section class="featured-property-section mt-5" id="featured-property-section" style="background: white;">
        <div class="container">
            <div class="row text-center">
                <div class="col-lg-8 mx-auto col-sm-12 col-xs-12">
                    <h2 class="section-heading item-space" style="font-weight: 700; font-size: 42px; color: black;">Searching for Best Place?</h2>
                    <div class="separator" style="width: 100px; height: 4px; background-color: #10AC84; margin: 0 auto;"></div>
                    <p class="section-description mt-2 item-space" style="font-size: 18px; color: black;">Discover the perfect destination that combines luxury, comfort, and convenience.</p>
                </div>
            </div>

            <div class="row">
                <?php
                $args = array(
                    'post_type' => 'property',
                    'posts_per_page' => 6,
                    'post_status' => 'publish',
                );
                $query = new WP_Query($args);
                if ($query->have_posts()):
                    while ($query->have_posts()):
                        $query->the_post();
                        $price = get_field('price');
                        $bedrooms = get_field('bed');
                        $bathrooms = get_field('bath');
                        $rooms = get_field('rooms');
                        $size = get_field('property_size');
                        $location_terms = wp_get_post_terms(get_the_ID(), 'location');
                        $location_name = !empty($location_terms) ? $location_terms[0]->name : 'N/A';
                        ?>
                        <div class="col-lg-4 col-md-6 col-sm-12 col-xm-12 item-space mb-4">
                            <div class="property-card" style="border: 1px solid #e3e3e3; border-radius: 8px; overflow: hidden;">
                                <?php if (has_post_thumbnail()): ?>
                                    <div class="property-image" style="height: 250px; overflow: hidden;">
                                        <img src="<?php the_post_thumbnail_url('medium'); ?>" alt="<?php the_title(); ?>" style="width: 100%; height: 100%; object-fit: cover;">
                                    </div>
                                <?php endif; ?>
                                <div class="property-details" style="padding: 15px;">
                                    <h3 class="property-title" style="font-size: 22px; font-weight: bold; color: #333;"><?php the_title(); ?></h3>
                                    <p class="property-location" style="color: #888; margin-bottom: 10px;font-size:16px;">
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/location.png" alt="Location" style="width:20px;" /> <?php echo esc_html($location_name); ?>
                                    </p>
                                    <p class="property-info" style="color: #555;font-size:12px;">
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/bed.png" alt="Bed" style="width:20px;" />&nbsp; <?php echo esc_html($bedrooms); ?> Bed
                                        &nbsp;&nbsp;&nbsp;<img src="<?php echo get_template_directory_uri(); ?>/assets/bath.png" alt="Bath" style="width:20px;" /> &nbsp;<?php echo esc_html($bathrooms); ?> Bath
                                        &nbsp;&nbsp;&nbsp;<img src="<?php echo get_template_directory_uri(); ?>/assets/rooms.png" alt="Rooms" style="width:20px;" /> &nbsp;<?php echo esc_html($bathrooms); ?> Rooms
                                        &nbsp;&nbsp;&nbsp;<img src="<?php echo get_template_directory_uri(); ?>/assets/size.png" alt="size" style="width:20px;" /> &nbsp;<?php echo esc_html($size); ?> sq. ft.
                                    </p>
                                    <p class="property-price" style="color: #10AC84; font-weight: bold; font-size: 18px;">
                                        $<?php echo number_format($price); ?>
                                    </p>
                                    <button class="btn" style="background-color: #10AC84;padding:5px 10px;color:white;font-size:15px;">See More</button>
                                </div>
                            </div>
                        </div>
                    <?php endwhile;
                    wp_reset_postdata();
                else: ?>
                    <p>No properties found.</p>
                <?php endif; ?>
            </div>
            <?php
            // Check if on the home page and retrieve the ACF URL field
            if (is_front_page()) {
                $button_url = get_field('see_more_properties'); // Replace with your ACF field name
            
                if ($button_url): ?>
                    <div class="see-more-properties" style="text-align: center; margin-top: 20px;">
                        <a href="<?php echo esc_url($button_url); ?>" class="btn"
                            style="background-color: #10AC84; color: white; font-size: 18px; padding: 10px 20px;">See More
                            Properties</a>
                    </div>
                <?php endif;
            }
            ?>
        </div>
    </section>

    <section class="browse-property-section mt-5" id="browse-property-section" style="background:#10AC84;height:550px;">
        <div class="container-fluid">
            <div class="row">
                <?php
                // Get custom field values
                $heading = get_field('browse_heading');
                $description = get_field('browse_description');
                $button_link = get_field('browse_button');
                $button_text = get_field('browse_button_text');
                $background_image = get_field('browse_property_image'); // Image field
                ?>

                <div class="custom-section" style="display: flex; align-items: center;">
                    <div style="flex: 1; padding: 20px 50px;color: white;">
                        <h1><?php echo esc_html($heading); ?></h1>
                        <p><?php echo esc_html($description); ?></p>
                        <div class="browse-property" style="text-align: left; margin-top: 20px;">
                            <a href="<?php echo esc_url($button_link); ?>" class="btn"
                                style="background-color: #140C40; color: white; font-size: 18px; padding: 10px 30px;border-radius:50px;"><?php echo esc_html($button_text); ?></a>
                        </div>
                    </div>
                    <div style="flex: 1;">
                        <?php if ($background_image): ?>
                            <img src="<?php echo esc_url($background_image['url']); ?>"
                                alt="<?php echo esc_attr($background_image['alt']); ?>"
                                style="width: 100%; height: 550px; object-fit: cover;">
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="category-property-section p-5" id="category-property-section" style="background:#F5F6F7;">
        <div class="container">
            <div class="row">
                <div class="steps-section"
                    style="display: flex; justify-content: space-between; align-items: flex-start; gap: 45px;padding:40px 0">
                    <?php
                    // Loop through 4 steps
                    for ($i = 1; $i <= 4; $i++):
                        // Get ACF field values
                        $step_number = get_field('steps_number_' . $i);
                        $step_image = get_field('steps_image_' . $i);
                        $category_title = get_field('category_title_' . $i);
                        $category_description = get_field('category_description_' . $i);
                        ?>
                        <div class="step-item" style="text-align: center; max-width: 250px;">
                            <div class="step-image" style="position: relative; margin-bottom: 40px;">
                                <?php if ($step_image): ?>
                                    <img src="<?php echo esc_url($step_image['url']); ?>" alt="Step <?php echo $i; ?>"
                                        style="width: 220px; height: 220px; border-radius: 50%; object-fit: cover;box-shadow:0 10px 10px #a5a4a4;border:2px solid #0f9d58"
                                        class="steps-image">
                                <?php endif; ?>
                                <div class="step-number"
                                    style="position: absolute; bottom: -20px; left: 50%; transform: translateX(-50%); background-color: #0f9d58; color: white; width: 50px; height: 50px; border-radius: 50%; display: flex; justify-content: center; align-items: center; font-weight: bold;">
                                    <?php echo esc_html($step_number); ?>
                                </div>
                            </div>
                            <h3 style="font-size: 25px; font-weight: bold; margin-bottom: 10px;">
                                <?php echo esc_html($category_title); ?></h3>
                            <p style="font-size: 18px; color: #666;"><?php echo esc_html($category_description); ?></p>
                        </div>
                    <?php endfor; ?>
                </div>
            </div>
        </div>
    </section>

    <section class="team-section mt-3" id="team-section">
        <div class="container">
            <div class="row">
                <div class="team-section" style="padding:40px 0; text-align: center;">
                    <?php
                    $team_heading = get_field('team_heading');
                    if ($team_heading): ?>
                        <h1 style="font-size: 50px; font-weight: bold; margin-bottom: 40px;">
                            <?php echo esc_html($team_heading); ?></h1>
                    <?php endif; ?>

                    <div class="team-cards" style="display: flex; justify-content: center; flex-wrap: wrap; gap: 45px;">
                        <?php
                        // Loop through 4 steps
                        for ($i = 1; $i <= 4; $i++):
                            // Get ACF field values
                            $team_image = get_field('team_image_' . $i);
                            $team_member = get_field('team_member_' . $i);
                            $team_member_designation = get_field('team_member_designation_' . $i);
                            ?>
                            <div class="step-item" style="text-align: center; max-width: 250px;">
                                <div class="step-image" style="position: relative; margin-bottom: 40px;">
                                    <?php if ($team_image): ?>
                                        <img src="<?php echo esc_url($team_image['url']); ?>"
                                            alt="Team Member <?php echo $i; ?>"
                                            style="width: 250px; height: 300px; object-fit: cover; box-shadow: 0 10px 10px #a5a4a4; border-radius: 0px;background-position:center;"
                                            class="team-image">
                                    <?php endif; ?>
                                </div>
                                <h3 style="font-size: 25px; font-weight: bold; margin-bottom: 10px;">
                                    <?php echo esc_html($team_member); ?></h3>
                                <p style="font-size: 18px; color: #666;"><?php echo esc_html($team_member_designation); ?>
                                </p>
                            </div>
                        <?php endfor; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="property-section mt-3" id="property-section">
        <div class="container-fluid">
            <div class="row">
                <div class="property-section" style="padding:40px 0; text-align: center;">
                    <div class="property-cards" style="display: flex; justify-content: center; flex-wrap: wrap;">
                        <?php
                        // Loop through 5 properties
                        for ($i = 1; $i <= 5; $i++):
                            // Get ACF field values
                            $property_image = get_field('property_image_' . $i);
                            $city_title = get_field('city_title_' . $i);
                            $city_url = get_field('city_url_' . $i);
                            ?>
                            <div class="property-item"
                                style="text-align: center; max-width: 400px; position: relative; margin-bottom: 40px;">
                                <div class="property-image"
                                    style="position: relative; overflow: hidden; height: 400px;width:300px;">
                                    <?php if ($property_image): ?>
                                        <img src="<?php echo esc_url($property_image['url']); ?>"
                                            alt="Property <?php echo $i; ?>" class="property-image-img">
                                    <?php endif; ?>
                                </div>
                                <div class="browse-property"
                                    style="margin-top: 20px; position:relative; z-index:2; top:-110px;">
                                    <a href="<?php echo esc_url($city_url); ?>" class="btn"
                                        style="background-color: #140C40; color: white; font-size: 18px; padding: 10px 30px; border-radius:50px;"><?php echo esc_html($city_title); ?></a>
                                </div>
                            </div>
                        <?php endfor; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <style>
        .property-image-img {
            width: 100%;
            height: 80%;
            object-fit: cover;
            border-radius: 0px;
        }
        .property-section{
            height: 400px;
        }
    </style>

</div>

<?php
get_footer();
